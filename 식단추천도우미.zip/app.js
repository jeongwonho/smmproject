const mealSlots = ["아침", "점심", "저녁", "간식", "추가 간식"];
const dayNames = ["월", "화", "수", "목", "금", "토", "일"];

const mealDatabase = [
  {
    name: "닭가슴살 현미볼",
    description: "구운 닭가슴살과 현미, 구운 채소를 담은 든든한 한 그릇 메뉴",
    tags: ["balanced", "high-protein"],
    budget: "medium",
    cookTime: "moderate",
    calories: 430,
    protein: 37,
    carbs: 39,
    fat: 11,
    ingredients: ["닭가슴살", "현미", "브로콜리"],
  },
  {
    name: "연어 아보카도 샐러드",
    description: "연어와 아보카도, 채소를 더한 상큼한 고단백 샐러드",
    tags: ["balanced", "high-protein", "low-carb"],
    budget: "high",
    cookTime: "quick",
    calories: 390,
    protein: 30,
    carbs: 15,
    fat: 22,
    ingredients: ["연어", "아보카도", "양상추"],
  },
  {
    name: "두부 채소 덮밥",
    description: "두부와 버섯, 제철 채소를 볶아 올린 담백한 한식 스타일",
    tags: ["balanced", "vegetarian"],
    budget: "low",
    cookTime: "moderate",
    calories: 410,
    protein: 24,
    carbs: 46,
    fat: 12,
    ingredients: ["두부", "버섯", "파프리카"],
  },
  {
    name: "그릭요거트 베리볼",
    description: "그릭요거트와 베리, 견과류를 곁들인 간단한 아침 메뉴",
    tags: ["balanced", "high-protein"],
    budget: "medium",
    cookTime: "quick",
    calories: 280,
    protein: 18,
    carbs: 26,
    fat: 10,
    ingredients: ["요거트", "블루베리", "아몬드"],
  },
  {
    name: "병아리콩 샐러드 랩",
    description: "병아리콩과 채소를 또띠아에 말아 간편하게 먹는 채식 랩",
    tags: ["vegetarian", "balanced"],
    budget: "low",
    cookTime: "quick",
    calories: 340,
    protein: 15,
    carbs: 42,
    fat: 9,
    ingredients: ["병아리콩", "또띠아", "토마토"],
  },
  {
    name: "소고기 야채볶음",
    description: "기름기를 줄인 소고기와 채소를 빠르게 볶아낸 저탄수 식단",
    tags: ["high-protein", "low-carb"],
    budget: "high",
    cookTime: "quick",
    calories: 360,
    protein: 33,
    carbs: 14,
    fat: 17,
    ingredients: ["소고기", "양파", "버섯"],
  },
  {
    name: "계란 시금치 오픈토스트",
    description: "통밀빵 위에 계란과 시금치를 올린 브런치 스타일 메뉴",
    tags: ["balanced"],
    budget: "low",
    cookTime: "quick",
    calories: 320,
    protein: 19,
    carbs: 28,
    fat: 12,
    ingredients: ["계란", "시금치", "통밀빵"],
  },
  {
    name: "새우 퀴노아 보울",
    description: "탱글한 새우와 퀴노아, 채소를 곁들인 균형 잡힌 플레이트",
    tags: ["balanced", "high-protein"],
    budget: "high",
    cookTime: "moderate",
    calories: 420,
    protein: 31,
    carbs: 36,
    fat: 13,
    ingredients: ["새우", "퀴노아", "오이"],
  },
  {
    name: "두유 단백질 스무디",
    description: "두유와 바나나, 단백질 파우더로 만든 포만감 높은 간식",
    tags: ["high-protein", "vegetarian"],
    budget: "medium",
    cookTime: "quick",
    calories: 250,
    protein: 22,
    carbs: 18,
    fat: 7,
    ingredients: ["두유", "바나나", "단백질 파우더"],
  },
  {
    name: "닭안심 채소쌈",
    description: "닭안심과 채소를 쌈채소에 싸 먹는 저탄수 저녁 메뉴",
    tags: ["low-carb", "high-protein"],
    budget: "medium",
    cookTime: "moderate",
    calories: 350,
    protein: 34,
    carbs: 12,
    fat: 13,
    ingredients: ["닭안심", "상추", "오이"],
  },
  {
    name: "토마토 렌틸 스튜",
    description: "렌틸콩과 토마토를 푹 끓여 만든 포근한 채식 스튜",
    tags: ["vegetarian", "balanced"],
    budget: "low",
    cookTime: "flexible",
    calories: 370,
    protein: 19,
    carbs: 49,
    fat: 8,
    ingredients: ["렌틸콩", "토마토", "양파"],
  },
  {
    name: "참치 오이 김밥볼",
    description: "참치와 오이, 현미밥을 섞어 만든 가벼운 도시락 메뉴",
    tags: ["balanced", "high-protein"],
    budget: "medium",
    cookTime: "quick",
    calories: 390,
    protein: 28,
    carbs: 34,
    fat: 11,
    ingredients: ["참치", "오이", "현미밥"],
  },
  {
    name: "두부 스테이크 플레이트",
    description: "두부 스테이크와 구운 채소를 곁들인 고단백 채식 식단",
    tags: ["vegetarian", "high-protein"],
    budget: "medium",
    cookTime: "moderate",
    calories: 400,
    protein: 27,
    carbs: 24,
    fat: 18,
    ingredients: ["두부", "애호박", "파프리카"],
  },
  {
    name: "오트밀 바나나 팬케이크",
    description: "오트밀과 바나나로 만든 부담 적은 에너지 충전 메뉴",
    tags: ["balanced", "vegetarian"],
    budget: "low",
    cookTime: "quick",
    calories: 310,
    protein: 12,
    carbs: 45,
    fat: 8,
    ingredients: ["오트밀", "바나나", "계란"],
  },
  {
    name: "에그 머핀 컵",
    description: "계란과 채소를 구워 만든 미리 준비하기 좋은 단백질 간식",
    tags: ["high-protein", "low-carb"],
    budget: "low",
    cookTime: "moderate",
    calories: 210,
    protein: 17,
    carbs: 6,
    fat: 12,
    ingredients: ["계란", "파프리카", "치즈"],
  },
  {
    name: "메밀면 닭가슴살 샐러드",
    description: "메밀면에 닭가슴살과 채소를 얹은 산뜻한 점심 메뉴",
    tags: ["balanced", "high-protein"],
    budget: "medium",
    cookTime: "quick",
    calories: 410,
    protein: 29,
    carbs: 38,
    fat: 10,
    ingredients: ["메밀면", "닭가슴살", "채소"],
  },
  {
    name: "버섯 콜리플라워 볶음밥",
    description: "콜리플라워 라이스로 탄수화물을 줄인 포만감 있는 볶음밥",
    tags: ["low-carb", "vegetarian"],
    budget: "medium",
    cookTime: "moderate",
    calories: 330,
    protein: 16,
    carbs: 20,
    fat: 17,
    ingredients: ["콜리플라워", "버섯", "계란"],
  },
];

const form = document.querySelector("#profile-form");
const dailyCards = document.querySelector("#daily-cards");
const weeklyPlanner = document.querySelector("#weekly-planner");
const savedPlans = document.querySelector("#saved-plans");
const insightBox = document.querySelector("#insight-box");
const dailySummary = document.querySelector("#daily-summary");
const mealCardTemplate = document.querySelector("#meal-card-template");

const rerollDayButton = document.querySelector("#reroll-day-button");
const rerollWeekButton = document.querySelector("#reroll-week-button");
const savePlanButton = document.querySelector("#save-plan-button");
const resetFormButton = document.querySelector("#reset-form-button");
const loadDemoButton = document.querySelector("#load-demo-button");

const STORAGE_KEYS = {
  current: "meal-helper-current-plan",
  saved: "meal-helper-saved-plans",
};

let appState = {
  profile: null,
  dailyPlan: [],
  weeklyPlan: [],
};

function parseList(value) {
  return value
    .split(",")
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);
}

function getTargetCalories(goal) {
  if (goal === "loss") return 1600;
  if (goal === "gain") return 2300;
  return 1950;
}

function formatBudget(budget) {
  return {
    low: "절약형",
    medium: "보통",
    high: "여유 있음",
  }[budget];
}

function formatCookTime(cookTime) {
  return {
    quick: "15분 이내",
    moderate: "30분 이내",
    flexible: "시간 여유 있음",
  }[cookTime];
}

function scoreMeal(meal, profile, slot, usedNames = new Set()) {
  const preferences = parseList(profile.preferences);
  const allergies = parseList(profile.allergies);
  const preferredBudget = profile.budget;
  const preferredCookTime = profile.cookTime;

  if (meal.ingredients.some((ingredient) => allergies.some((item) => ingredient.includes(item)))) {
    return -999;
  }

  if (usedNames.has(meal.name)) {
    return -50;
  }

  let score = 0;

  if (meal.tags.includes(profile.dietType)) score += 28;
  if (profile.dietType === "balanced" && meal.tags.includes("balanced")) score += 20;
  if (meal.budget === preferredBudget) score += 14;
  if (meal.cookTime === preferredCookTime) score += 14;

  if (preferences.some((item) => meal.ingredients.some((ingredient) => ingredient.includes(item)))) {
    score += 20;
  }

  if (profile.goal === "loss") {
    score += meal.calories <= 400 ? 12 : 4;
    score += meal.protein >= 20 ? 10 : 2;
  }

  if (profile.goal === "gain") {
    score += meal.calories >= 380 ? 12 : 4;
    score += meal.protein >= 25 ? 10 : 3;
  }

  if (profile.goal === "maintain") {
    score += meal.calories >= 280 && meal.calories <= 430 ? 10 : 4;
  }

  if (slot === "간식" || slot === "추가 간식") {
    score += meal.calories <= 300 ? 8 : -4;
  } else {
    score += meal.calories >= 300 ? 8 : -2;
  }

  return score;
}

function chooseMeal(profile, slot, usedNames = new Set()) {
  const scored = mealDatabase
    .map((meal) => ({ meal, score: scoreMeal(meal, profile, slot, usedNames) }))
    .filter((entry) => entry.score > -100)
    .sort((a, b) => b.score - a.score);

  if (!scored.length) {
    return null;
  }

  const topCandidates = scored.slice(0, 4);
  return (topCandidates[Math.floor(Math.random() * topCandidates.length)] || scored[0]).meal;
}

function buildDailyPlan(profile, existingUsed = new Set()) {
  const slots = mealSlots.slice(0, Number(profile.mealsPerDay));
  const usedNames = new Set(existingUsed);

  return slots.map((slot) => {
    const meal = chooseMeal(profile, slot, usedNames);
    if (!meal) {
      return {
        slot,
        meal: {
          name: "추천 가능한 메뉴를 찾지 못했어요",
          description: "제외 재료 조건이 많아 현재 데이터에서 일치하는 메뉴가 없습니다.",
          tags: ["balanced"],
          calories: 0,
          protein: 0,
          carbs: 0,
          fat: 0,
        },
      };
    }
    usedNames.add(meal.name);
    return { slot, meal };
  });
}

function buildWeeklyPlan(profile) {
  const weeklyUsed = new Set();

  return dayNames.map((day) => {
    const dailyPlan = buildDailyPlan(profile, weeklyUsed);
    dailyPlan.forEach((entry) => weeklyUsed.add(entry.meal.name));
    return { day, meals: dailyPlan };
  });
}

function calculateNutrition(plan) {
  return plan.reduce(
    (total, entry) => {
      total.calories += entry.meal.calories;
      total.protein += entry.meal.protein;
      total.carbs += entry.meal.carbs;
      total.fat += entry.meal.fat;
      return total;
    },
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );
}

function formatGoal(goal) {
  return {
    loss: "체중 감량",
    maintain: "체중 유지",
    gain: "근육 증가",
  }[goal];
}

function formatDietType(type) {
  return {
    balanced: "일반 균형식",
    "high-protein": "고단백",
    "low-carb": "저탄수",
    vegetarian: "채식 위주",
  }[type];
}

function renderDailyPlan() {
  if (!appState.dailyPlan.length) {
    dailyCards.className = "meal-grid empty-state";
    dailyCards.innerHTML = "<p>아직 생성된 식단이 없습니다.</p>";
    return;
  }

  const nutrition = calculateNutrition(appState.dailyPlan);
  dailyCards.className = "meal-grid";
  dailyCards.innerHTML = "";

  appState.dailyPlan.forEach((entry, index) => {
    const fragment = mealCardTemplate.content.cloneNode(true);
    fragment.querySelector(".meal-slot").textContent = entry.slot;
    fragment.querySelector(".meal-name").textContent = entry.meal.name;
    fragment.querySelector(".meal-desc").textContent = entry.meal.description;

    const tagRow = fragment.querySelector(".tag-row");
    entry.meal.tags.forEach((tag) => {
      const chip = document.createElement("span");
      chip.className = "tag";
      chip.textContent = formatDietType(tag) || tag;
      tagRow.appendChild(chip);
    });

    const nutritionRow = fragment.querySelector(".nutrition-row");
    [
      `칼로리 ${entry.meal.calories}kcal`,
      `단백질 ${entry.meal.protein}g`,
      `탄수 ${entry.meal.carbs}g`,
      `지방 ${entry.meal.fat}g`,
    ].forEach((value) => {
      const chip = document.createElement("span");
      chip.className = "nutrition-chip";
      chip.textContent = value;
      nutritionRow.appendChild(chip);
    });

    const swapButton = fragment.querySelector(".swap-button");
    swapButton.addEventListener("click", () => swapMeal(index));
    dailyCards.appendChild(fragment);
  });

  dailySummary.textContent = `총 ${nutrition.calories}kcal / 단백질 ${nutrition.protein}g 기준으로 구성된 하루 식단입니다.`;
}

function renderWeeklyPlan() {
  if (!appState.weeklyPlan.length) {
    weeklyPlanner.className = "planner-grid empty-state";
    weeklyPlanner.innerHTML = "<p>추천을 생성하면 주간 식단이 함께 표시됩니다.</p>";
    return;
  }

  weeklyPlanner.className = "planner-grid";
  weeklyPlanner.innerHTML = "";

  appState.weeklyPlan.forEach((dayPlan) => {
    const article = document.createElement("article");
    article.className = "planner-day";

    const title = document.createElement("h3");
    title.textContent = `${dayPlan.day}요일`;
    article.appendChild(title);

    const list = document.createElement("ol");
    list.className = "planner-list";
    dayPlan.meals.forEach((entry) => {
      const item = document.createElement("li");
      item.textContent = `${entry.slot}: ${entry.meal.name}`;
      list.appendChild(item);
    });

    article.appendChild(list);
    weeklyPlanner.appendChild(article);
  });
}

function renderInsights() {
  if (!appState.profile || !appState.dailyPlan.length) {
    insightBox.innerHTML = "<p>추천을 생성하면 여기에 반영된 조건과 칼로리 가이드가 표시됩니다.</p>";
    return;
  }

  const nutrition = calculateNutrition(appState.dailyPlan);
  const targetCalories = getTargetCalories(appState.profile.goal);
  const allergies = parseList(appState.profile.allergies);
  const preferences = parseList(appState.profile.preferences);

  insightBox.innerHTML = `
    <p><strong>목표</strong>: ${formatGoal(appState.profile.goal)} / <strong>유형</strong>: ${formatDietType(appState.profile.dietType)}</p>
    <p><strong>칼로리 가이드</strong>: 하루 권장 약 ${targetCalories}kcal, 현재 추천 ${nutrition.calories}kcal</p>
    <p><strong>예산 · 조리 시간</strong>: ${formatBudget(appState.profile.budget)} / ${formatCookTime(appState.profile.cookTime)}</p>
    <p><strong>제외 재료</strong>: ${allergies.length ? allergies.join(", ") : "없음"}</p>
    <p><strong>선호 반영</strong>: ${preferences.length ? preferences.join(", ") : "기본 균형 추천"}</p>
  `;
}

function loadSavedPlans() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.saved) || "[]");
}

function renderSavedPlans() {
  const saved = loadSavedPlans();

  if (!saved.length) {
    savedPlans.className = "saved-list empty-state";
    savedPlans.innerHTML = "<p>저장된 식단이 없습니다.</p>";
    return;
  }

  savedPlans.className = "saved-list";
  savedPlans.innerHTML = "";

  saved.slice(0, 4).forEach((plan) => {
    const item = document.createElement("article");
    item.className = "saved-item";
    const title = document.createElement("h3");
    title.textContent = plan.title;
    const meta = document.createElement("p");
    meta.className = "saved-meta";
    meta.textContent = `${plan.createdAt} · ${plan.meals.map((entry) => entry.meal.name).join(", ")}`;
    item.append(title, meta);
    savedPlans.appendChild(item);
  });
}

function syncCurrentPlan() {
  localStorage.setItem(STORAGE_KEYS.current, JSON.stringify(appState));
}

function generatePlans(profile) {
  appState.profile = profile;
  appState.dailyPlan = buildDailyPlan(profile);
  appState.weeklyPlan = buildWeeklyPlan(profile);
  syncCurrentPlan();
  renderDailyPlan();
  renderWeeklyPlan();
  renderInsights();
}

function swapMeal(index) {
  if (!appState.profile) return;

  const usedNames = new Set(appState.dailyPlan.map((entry, entryIndex) => (entryIndex === index ? null : entry.meal.name)));
  const slot = appState.dailyPlan[index].slot;
  const replacement = chooseMeal(appState.profile, slot, usedNames);
  if (!replacement) return;
  appState.dailyPlan[index] = { slot, meal: replacement };
  syncCurrentPlan();
  renderDailyPlan();
  renderInsights();
}

function rerollDailyPlan() {
  if (!appState.profile) return;
  appState.dailyPlan = buildDailyPlan(appState.profile);
  syncCurrentPlan();
  renderDailyPlan();
  renderInsights();
}

function rerollWeeklyPlan() {
  if (!appState.profile) return;
  appState.weeklyPlan = buildWeeklyPlan(appState.profile);
  syncCurrentPlan();
  renderWeeklyPlan();
}

function saveCurrentPlan() {
  if (!appState.profile || !appState.dailyPlan.length) return;

  const saved = loadSavedPlans();
  const timestamp = new Date().toLocaleString("ko-KR");
  saved.unshift({
    title: `${formatGoal(appState.profile.goal)}용 ${formatDietType(appState.profile.dietType)} 식단`,
    createdAt: timestamp,
    meals: appState.dailyPlan,
  });
  localStorage.setItem(STORAGE_KEYS.saved, JSON.stringify(saved.slice(0, 8)));
  renderSavedPlans();
}

function loadDemoProfile() {
  form.goal.value = "loss";
  form.dietType.value = "high-protein";
  form.mealsPerDay.value = "4";
  form.budget.value = "medium";
  form.cookTime.value = "quick";
  form.allergies.value = "우유";
  form.preferences.value = "닭가슴살, 연어, 두부";
  form.notes.value = "점심은 간편식, 저녁은 너무 무겁지 않게";
}

function resetApp() {
  form.reset();
  form.mealsPerDay.value = "4";
  form.budget.value = "medium";
  form.cookTime.value = "moderate";
  appState = { profile: null, dailyPlan: [], weeklyPlan: [] };
  localStorage.removeItem(STORAGE_KEYS.current);
  renderDailyPlan();
  renderWeeklyPlan();
  renderInsights();
}

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const formData = new FormData(form);
  const profile = {
    goal: formData.get("goal"),
    dietType: formData.get("dietType"),
    mealsPerDay: formData.get("mealsPerDay"),
    budget: formData.get("budget"),
    cookTime: formData.get("cookTime"),
    allergies: formData.get("allergies")?.toString().trim() || "",
    preferences: formData.get("preferences")?.toString().trim() || "",
    notes: formData.get("notes")?.toString().trim() || "",
  };

  generatePlans(profile);
});

rerollDayButton.addEventListener("click", rerollDailyPlan);
rerollWeekButton.addEventListener("click", rerollWeeklyPlan);
savePlanButton.addEventListener("click", saveCurrentPlan);
resetFormButton.addEventListener("click", resetApp);
loadDemoButton.addEventListener("click", loadDemoProfile);

function initialize() {
  const stored = localStorage.getItem(STORAGE_KEYS.current);
  if (stored) {
    appState = JSON.parse(stored);
    renderDailyPlan();
    renderWeeklyPlan();
    renderInsights();
  }
  renderSavedPlans();
}

initialize();
